import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { RefreshCw, Settings2, Unplug } from "lucide-react";
import { toast } from "sonner";
import { calendarConnectionStatus, completeCalendarConnection, startCalendarConnection, calendarConfiguration, saveCalendarConfiguration, synchronizeMyCalendar, disconnectMyCalendar } from "@/lib/calendar.functions";
import { Btn, Field, inputCls } from "./ui";

export function CalendarConnect() {
  const qc = useQueryClient();
  const start = useServerFn(startCalendarConnection), complete = useServerFn(completeCalendarConnection);
  const { data } = useQuery({ queryKey: ["calendar-connection"], queryFn: () => calendarConnectionStatus() });
  const [busy, setBusy] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const sync = useServerFn(synchronizeMyCalendar), save = useServerFn(saveCalendarConfiguration), disconnect = useServerFn(disconnectMyCalendar);
  const configFn = useServerFn(calendarConfiguration);
  const { data: config, error: configError } = useQuery({ queryKey: ["calendar-configuration"], queryFn: () => configFn(), enabled: Boolean(data?.connected) });
  const [lesson, setLesson] = useState("primary"), [privateCalendars, setPrivateCalendars] = useState<string[]>([]);
  useEffect(() => { if(config?.settings) {setLesson(config.settings.lesson_calendar_id);setPrivateCalendars(config.settings.busy_calendar_ids);} }, [config]);
  const refresh = async () => { await Promise.all([qc.invalidateQueries({queryKey:["calendar-connection"]}),qc.invalidateQueries({queryKey:["calendar-configuration"]}),qc.invalidateQueries({queryKey:["bookings"]}),qc.invalidateQueries({queryKey:["slots"]})]); };
  const action = async (task: () => Promise<unknown>, message: string) => {setBusy(true);try{await task();await refresh();toast.success(message);}catch(error){toast.error(error instanceof Error?error.message:"Nie udało się wykonać operacji");}finally{setBusy(false);} };
  const connect = async () => {
    const popup = window.open("", "calendar-consent", "width=600,height=720");
    if (!popup) { toast.error("Zezwól na otwarcie okna Google"); return; }
    setBusy(true);
    try {
      const result = await start();
      const code = await new Promise<string>((resolve, reject) => {
        const cleanup = () => { window.removeEventListener("message", listener); window.clearInterval(poll); window.clearTimeout(timeout); };
        const listener = (event: MessageEvent) => {
          if (event.origin !== window.location.origin || event.source !== popup || !["calendar-connected", "calendar-failed"].includes(event.data?.type)) return;
          cleanup();
          if (event.data.type === "calendar-connected" && typeof event.data.code === "string") resolve(event.data.code);
          else reject(new Error("Połączenie nie zostało ukończone"));
        };
        const poll = window.setInterval(() => { if (popup.closed) { cleanup(); reject(new Error("Okno połączenia zamknięte")); } }, 500);
        const timeout = window.setTimeout(() => { cleanup(); reject(new Error("Połączenie trwało zbyt długo")); }, 300_000);
        window.addEventListener("message", listener);
        popup.location.href = result.authorizationUrl;
      });
      await complete({ data: { code } });
      await qc.invalidateQueries({ queryKey: ["calendar-connection"] });
      await qc.invalidateQueries({ queryKey: ["calendar-configuration"] });
      setExpanded(true);
      toast.success("Połączono z Google Calendar");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Nie udało się połączyć"); popup.close(); }
    finally { setBusy(false); }
  };
  return <section className="mb-5 border-b border-border pb-4">
    <div className="mb-3 space-y-2 text-sm text-muted-foreground" id="calendar-data-notice">
      <p>Google Calendar służy do synchronizacji rezerwacji i sprawdzania zajętości w wybranych przez Ciebie kalendarzach. Panel odczytuje listę kalendarzy i wydarzenia oraz tworzy, zmienia lub usuwa wydarzenia jazd. Odpowiednio opisane wydarzenia z kalendarza jazd mogą także aktualizować rezerwacje w panelu.</p>
      <p>Do Google mogą trafić imię i nazwisko kursanta, jego e-mail, kategoria kursu, bilans godzin, termin, miejsce i notatki jazdy. Przy potwierdzeniu Google może wysłać kursantowi zaproszenie. Dane są obsługiwane przez Lovable Connector Gateway; ustawienia synchronizacji, powiązania wydarzeń i przedziały zajętości są zapisywane w panelu.</p>
      <p>Połączenie jest dobrowolne. Możesz je odłączyć w ustawieniach poniżej lub cofnąć dostęp w koncie Google. Odłączenie nie usuwa rezerwacji ani wydarzeń już zapisanych w Google. Nie wpisuj do notatek zbędnych danych wrażliwych.</p>
      <a className="underline underline-offset-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4" href="https://jablonski-naukajazdy.pl/polityka-prywatnosci/#google-calendar" target="_blank" rel="noopener noreferrer">Zasady wykorzystania danych i odłączenia Google Calendar</a>
    </div>
    <div className="flex flex-wrap items-center gap-3"><span className="text-sm text-muted-foreground">Google Calendar: {data?.connected ? "połączony" : data?.reconnect ? "wymaga ponownego połączenia" : "niepołączony"}</span><Btn variant="outline" disabled={busy} onClick={connect}>{busy ? "Proszę czekać…" : data?.connected || data?.reconnect ? "Połącz ponownie" : "Połącz Google Calendar"}</Btn>
      {data?.connected ? <><Btn variant="ghost" title="Ustawienia kalendarzy" aria-label="Ustawienia kalendarzy" onClick={()=>setExpanded(!expanded)}><Settings2 size={18}/></Btn><Btn variant="outline" disabled={busy} onClick={()=>action(async()=>{const result=await sync();if(result.reconnect)throw new Error("Połącz ponownie Google Calendar");if(result.issues?.length)throw new Error(result.issues.join(" · "));},"Zsynchronizowano kalendarz")}><RefreshCw size={16}/>Synchronizuj</Btn></>:null}
    </div>
    {config?.settings?.last_sync_at?<p className="mt-2 text-xs text-muted-foreground">Ostatnia synchronizacja: {new Date(config.settings.last_sync_at).toLocaleString("pl-PL",{timeZone:"Europe/Warsaw"})}</p>:null}
    {config?.settings?.sync_error?<p role="alert" className="mt-2 text-sm text-destructive">{config.settings.sync_error}</p>:null}
    {configError?<p role="alert" className="mt-2 text-sm text-destructive">Nie udało się pobrać kalendarzy. Spróbuj ponownie.</p>:null}
    {expanded&&data?.connected?<div className="mt-4 grid max-w-xl gap-4">
      <Field label="Kalendarz jazd"><select className={inputCls} value={lesson} onChange={e=>setLesson(e.target.value)}><option value="primary">Kalendarz główny</option>{config?.calendars.filter(c=>c.writable).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
      <fieldset><legend className="mb-2 text-xs font-semibold text-muted-foreground">Kalendarze blokujące dostępność</legend><div className="grid gap-2">{config?.calendars.map(c=><label key={c.id} className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1 accent-primary" checked={privateCalendars.includes(c.id)} onChange={e=>setPrivateCalendars(e.target.checked?[...privateCalendars,c.id]:privateCalendars.filter(id=>id!==c.id))}/><span className="min-w-0 break-words">{c.name}</span></label>)}</div></fieldset>
      <div className="flex flex-wrap gap-2"><Btn disabled={busy} onClick={()=>action(()=>save({data:{lessonCalendarId:lesson,busyCalendarIds:privateCalendars}}),"Zapisano kalendarze")}>Zapisz kalendarze</Btn><Btn variant="danger" disabled={busy} onClick={()=>{if(window.confirm("Odłączyć Google Calendar? Jazdy w panelu pozostaną zapisane."))void action(()=>disconnect(),"Odłączono Google Calendar");}}><Unplug size={16}/>Odłącz</Btn></div>
    </div>:null}
  </section>;
}